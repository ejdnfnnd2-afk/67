# Roblox AI Analyzer — GitHub → Raw → Executor → Server → Claude

This project contains a safe analyzer that sends **client-visible Roblox Instance metadata** to a local Python server. The server asks Claude to classify the detected systems and returns JSON for the GUI.

## Structure

```text
roblox-ai-analyzer/
├── roblox/
│   └── ROBLOX_AI_ANALYZER.lua
├── server/
│   ├── analyzer.py
│   ├── requirements.txt
│   └── .env.example
├── .env.example
└── README_ROBLOX_AI.md
```

## 1. Server

From the `server` directory:

```bash
python -m venv .venv
```

Activate the environment, then:

```bash
pip install -r requirements.txt
```

Copy `server/.env.example` to `server/.env` and set `ANTHROPIC_API_KEY`.

Start it with:

```bash
uvicorn analyzer:app --host 127.0.0.1 --port 8000
```

Check:

```text
http://127.0.0.1:8000/health
```

## 2. Roblox script

`roblox/ROBLOX_AI_ANALYZER.lua` uses the local endpoint:

```text
http://127.0.0.1:8000/v1/roblox/analyze
```

It collects only `GetDescendants()` metadata (`GetFullName`, `Name`, `ClassName`) and displays Claude's classification in the GUI.

## 3. GitHub Raw

After pushing the repository to GitHub, the Lua file can be loaded from its Raw URL. Replace `TU_USUARIO` and `TU_REPO` with your repository:

```text
https://raw.githubusercontent.com/TU_USUARIO/TU_REPO/main/roblox/ROBLOX_AI_ANALYZER.lua
```

The Raw URL is only the client script. **Do not put `ANTHROPIC_API_KEY` in the Lua file or in GitHub.**

## Safety boundary

The analyzer does not decompile scripts, hook metamethods, intercept protected traffic, execute unknown remotes, or generate exploit/bypass instructions. Its purpose is to understand client-visible game structure and suggest high-level legitimate gameplay concepts.
