"""Safe Roblox client-visible game analyzer."""

from __future__ import annotations

import json
import re
from typing import Any

from pydantic import BaseModel, Field

MAX_INSTANCES = 6000
MAX_TEXT = 18000


class RobloxInstance(BaseModel):
    path: str = Field(max_length=700)
    name: str = Field(max_length=200)
    class_name: str = Field(max_length=120)


class RobloxAnalyzeRequest(BaseModel):
    game_name: str = Field(default="Unknown", max_length=200)
    place_id: str = Field(default="Unknown", max_length=80)
    instances: list[RobloxInstance] = Field(
        default_factory=list, max_length=MAX_INSTANCES
    )


class RobloxFinding(BaseModel):
    category: str
    name: str
    confidence: int = Field(ge=0, le=100)
    evidence: list[str] = Field(default_factory=list, max_length=12)
    explanation: str = Field(default="", max_length=3000)
    concept: str = Field(default="", max_length=3000)


class RobloxAnalyzeResponse(BaseModel):
    game_name: str
    place_id: str
    findings: list[RobloxFinding]
    summary: str


def build_analysis_prompt(data: RobloxAnalyzeRequest) -> str:
    """Build a bounded prompt from client-visible metadata only."""
    rows = [
        {"path": item.path, "name": item.name, "class": item.class_name}
        for item in data.instances[:MAX_INSTANCES]
    ]
    snapshot = json.dumps(rows, ensure_ascii=False, separators=(",", ":"))
    if len(snapshot) > MAX_TEXT:
        snapshot = snapshot[:MAX_TEXT] + "..."

    return f"""You are a Roblox game-structure analyst.
Analyze ONLY the client-visible instance metadata supplied below. Do not invent hidden server code,
credentials, vulnerabilities, or remote-call arguments.

Return ONLY valid JSON matching this schema:
{{
  "summary": "short summary",
  "findings": [
    {{
      "category": "AUTO_STRENGTH|AUTO_REBIRTH|PETS|TRAINING|SHOP|COMBAT|REWARD|MOVEMENT|UI|OTHER",
      "name": "human-readable finding",
      "confidence": 0,
      "evidence": ["path/class/name evidence"],
      "explanation": "why the metadata suggests this system",
      "concept": "safe high-level implementation concept, not exploit instructions"
    }}
  ]
}}

Rules:
- Confidence must be 0-100 and reflect evidence strength.
- Only report a category when there is meaningful evidence.
- Do not claim that a RemoteEvent/RemoteFunction can be abused.
- Do not provide exploit code, remote argument recipes, hooks, decompilers, or bypasses.
- For automation ideas, describe the legitimate gameplay concept at a high level.

Game: {data.game_name}
PlaceId: {data.place_id}
Client-visible instances:
{snapshot}
"""


def parse_ai_json(text: str) -> RobloxAnalyzeResponse:
    """Parse strict JSON, with a small fenced-JSON fallback."""
    raw = text.strip()
    match = re.search(r"```(?:json)?\s*(\{.*\})\s*```", raw, re.DOTALL)
    if match:
        raw = match.group(1)
    start = raw.find("{")
    end = raw.rfind("}")
    if start >= 0 and end > start:
        raw = raw[start : end + 1]
    payload: Any = json.loads(raw)
    return RobloxAnalyzeResponse.model_validate(payload)
