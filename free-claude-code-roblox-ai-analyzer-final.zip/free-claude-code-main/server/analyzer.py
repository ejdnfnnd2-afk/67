"""Safe Roblox client-visible metadata analyzer backed by Claude."""
from __future__ import annotations

import json
import os
import re
from typing import Any

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()

MAX_INSTANCES = 6000
MAX_TEXT = 18000
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
DEFAULT_MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5")

class RobloxInstance(BaseModel):
    path: str = Field(max_length=700)
    name: str = Field(max_length=200)
    class_name: str = Field(max_length=120)

class RobloxAnalyzeRequest(BaseModel):
    game_name: str = Field(default="Unknown", max_length=200)
    place_id: str = Field(default="Unknown", max_length=80)
    instances: list[RobloxInstance] = Field(default_factory=list, max_length=MAX_INSTANCES)

class RobloxFinding(BaseModel):
    category: str
    name: str
    confidence: int = Field(ge=0, le=100)
    evidence: list[str] = Field(default_factory=list, max_length=12)
    explanation: str = Field(default="", max_length=3000)
    concept: str = Field(default="", max_length=3000)

class RobloxAnalyzeResponse(BaseModel):
    game_name: str
    place_id: str
    findings: list[RobloxFinding]
    summary: str

SYSTEM_PROMPT = """You are a Roblox game-structure analyst.
Analyze ONLY client-visible Instance metadata supplied by the user.
Do not infer hidden server code, vulnerabilities, credentials, exploit paths, remote-call arguments, hooks, decompilation, or bypasses.
Return only JSON matching the requested schema.
For automation ideas, describe legitimate high-level gameplay concepts, not executor/exploit instructions.
Categories allowed: AUTO_STRENGTH, AUTO_REBIRTH, PETS, TRAINING, SHOP, COMBAT, REWARD, MOVEMENT, UI, OTHER.
"""

def build_prompt(data: RobloxAnalyzeRequest) -> str:
    rows = [{"path": x.path, "name": x.name, "class": x.class_name} for x in data.instances[:MAX_INSTANCES]]
    snapshot = json.dumps(rows, ensure_ascii=False, separators=(",", ":"))
    if len(snapshot) > MAX_TEXT:
        snapshot = snapshot[:MAX_TEXT] + "..."
    return f"""Game: {data.game_name}\nPlaceId: {data.place_id}\n\nClient-visible instances:\n{snapshot}\n\nReturn ONLY valid JSON:\n{{\n  \"summary\": \"short summary\",\n  \"findings\": [\n    {{\n      \"category\": \"AUTO_STRENGTH|AUTO_REBIRTH|PETS|TRAINING|SHOP|COMBAT|REWARD|MOVEMENT|UI|OTHER\",\n      \"name\": \"human-readable finding\",\n      \"confidence\": 0,\n      \"evidence\": [\"path/class/name evidence\"],\n      \"explanation\": \"why the metadata suggests this system\",\n      \"concept\": \"safe high-level implementation concept\"\n    }}\n  ]\n}}\nConfidence is 0-100 and must reflect evidence strength. Only report meaningful evidence."""

def parse_json(text: str) -> dict[str, Any]:
    raw = text.strip()
    match = re.search(r"```(?:json)?\s*(\{.*\})\s*```", raw, re.DOTALL)
    if match:
        raw = match.group(1)
    start, end = raw.find("{"), raw.rfind("}")
    if start >= 0 and end > start:
        raw = raw[start:end + 1]
    return json.loads(raw)

async def call_claude(data: RobloxAnalyzeRequest) -> RobloxAnalyzeResponse:
    key = os.getenv("ANTHROPIC_API_KEY", "").strip()
    if not key:
        raise HTTPException(status_code=500, detail="ANTHROPIC_API_KEY is not configured")

    headers = {
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    payload = {
        "model": DEFAULT_MODEL,
        "max_tokens": 3000,
        "system": SYSTEM_PROMPT,
        "messages": [{"role": "user", "content": build_prompt(data)}],
    }
    timeout = float(os.getenv("CLAUDE_TIMEOUT", "60"))
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(ANTHROPIC_URL, headers=headers, json=payload)
            response.raise_for_status()
            body = response.json()
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text[:1000]
        raise HTTPException(status_code=502, detail=f"Claude API error: {detail}") from exc
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Claude connection error: {exc}") from exc

    text_parts = [item.get("text", "") for item in body.get("content", []) if item.get("type") == "text"]
    if not text_parts:
        raise HTTPException(status_code=502, detail="Claude returned no text")
    try:
        result = parse_json("\n".join(text_parts))
        result["game_name"] = data.game_name
        result["place_id"] = data.place_id
        return RobloxAnalyzeResponse.model_validate(result)
    except (json.JSONDecodeError, ValueError) as exc:
        raise HTTPException(status_code=502, detail="Claude returned invalid analyzer JSON") from exc

app = FastAPI(title="Roblox AI Analyzer", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["POST", "GET"], allow_headers=["*"])

@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "provider": "anthropic", "model": DEFAULT_MODEL}

@app.post("/v1/roblox/analyze", response_model=RobloxAnalyzeResponse)
async def analyze(data: RobloxAnalyzeRequest) -> RobloxAnalyzeResponse:
    return await call_claude(data)
